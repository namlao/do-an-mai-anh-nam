<div class="page-heading">
    <h3>{{ $namepage }}</h3>
</div>
